package test;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import base.TestBase;

public class LoginTest extends TestBase {


@Test
public void login()
{
	
	
	driver.findElement(By.xpath(or.getProperty("login"))).click();
	log.debug("Login button sucessfully clicked");
	Assert.assertTrue(isElementPresnt(By.xpath(or.getProperty("createaccount"))),"Button is not Present");
	log.debug("Test is Complete");
}


}
